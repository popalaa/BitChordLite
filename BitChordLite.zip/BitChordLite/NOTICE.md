# BitChord Lite

Files under `app/src/main/java/com/music/bitchord/{data,playback}` are derived from
BitChord (https://github.com/kushagrasinghx/BitChord), licensed GPL-3.0.
This project is therefore also GPL-3.0: copy BitChord's `LICENSE` file here,
keep this notice, and publish the source with any APK you distribute.

Changes: `LrcLib.kt` ported from OkHttp 5 to OkHttp 3.12 calls; `Http.kt` rewritten.
Everything else is copied unchanged.

Uses NewPipeExtractor (GPL-3.0, https://github.com/TeamNewPipe/NewPipeExtractor) to search and
read YouTube streams, and ExoPlayer (Apache-2.0) for playback.

Music search/streaming uses the Audius public API (https://audius.co). Artists are credited in the UI.
