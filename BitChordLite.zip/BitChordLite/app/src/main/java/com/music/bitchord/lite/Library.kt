package com.music.bitchord.lite

import android.content.Context
import android.content.SharedPreferences
import com.music.bitchord.source.Track
import org.json.JSONArray
import org.json.JSONObject

/** Everything the user keeps on the device: favorites, recent plays, playlists, downloaded songs. */
object Library {
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences("library", Context.MODE_PRIVATE)
    }

    private fun key(t: Track) = "${t.sourceId}:${t.id}"

    private fun toJson(t: Track) = JSONObject()
        .put("id", t.id).put("title", t.title).put("artist", t.artist)
        .put("dur", t.durationSec).put("src", t.sourceId).put("art", t.artworkUrl ?: "")

    private fun fromJson(o: JSONObject) = Track(
        id = o.getString("id"),
        title = o.optString("title", "?"),
        artist = o.optString("artist"),
        durationSec = o.optInt("dur"),
        sourceId = o.optString("src", "youtube"),
        artworkUrl = o.optString("art").ifEmpty { null },
    )

    private fun parseTracks(a: JSONArray): MutableList<Track> {
        val out = ArrayList<Track>(a.length())
        for (i in 0 until a.length()) runCatching { out.add(fromJson(a.getJSONObject(i))) }
        return out
    }

    private fun readList(name: String): MutableList<Track> {
        val raw = prefs.getString(name, null) ?: return ArrayList()
        return try { parseTracks(JSONArray(raw)) } catch (e: Exception) { ArrayList() }
    }

    private fun writeList(name: String, list: List<Track>) {
        val a = JSONArray()
        list.forEach { a.put(toJson(it)) }
        prefs.edit().putString(name, a.toString()).apply()
    }

    // ---- favorites ----
    fun favorites(): List<Track> = readList("favorites")
    fun isFavorite(t: Track) = favorites().any { key(it) == key(t) }

    /** Returns true when the song is now a favorite. */
    fun toggleFavorite(t: Track): Boolean {
        val list = readList("favorites")
        val existing = list.indexOfFirst { key(it) == key(t) }
        return if (existing >= 0) {
            list.removeAt(existing); writeList("favorites", list); false
        } else {
            list.add(0, t); writeList("favorites", list); true
        }
    }

    // ---- recently played ----
    fun recents(): List<Track> = readList("recents")

    fun addRecent(t: Track) {
        val list = readList("recents")
        list.removeAll { key(it) == key(t) }
        list.add(0, t)
        while (list.size > 30) list.removeAt(list.lastIndex)
        writeList("recents", list)
    }

    // ---- downloads (the files themselves are managed by Downloads) ----
    fun downloads(): List<Track> = readList("downloads")

    fun addDownloaded(t: Track) {
        val list = readList("downloads")
        list.removeAll { key(it) == key(t) }
        list.add(0, t)
        writeList("downloads", list)
    }

    fun removeDownloaded(t: Track) {
        val list = readList("downloads")
        list.removeAll { key(it) == key(t) }
        writeList("downloads", list)
    }

    // ---- playlists ----
    private fun readPlaylists(): JSONObject =
        try { JSONObject(prefs.getString("playlists", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun writePlaylists(o: JSONObject) = prefs.edit().putString("playlists", o.toString()).apply()

    fun playlistNames(): List<String> {
        val o = readPlaylists()
        val names = ArrayList<String>()
        val it = o.keys()
        while (it.hasNext()) names.add(it.next())
        return names
    }

    fun playlist(name: String): List<Track> {
        val a = readPlaylists().optJSONArray(name) ?: return emptyList()
        return parseTracks(a)
    }

    /** False when the name is empty or already used. */
    fun createPlaylist(name: String): Boolean {
        val n = name.trim()
        val o = readPlaylists()
        if (n.isEmpty() || o.has(n)) return false
        o.put(n, JSONArray())
        writePlaylists(o)
        return true
    }

    fun deletePlaylist(name: String) {
        val o = readPlaylists()
        o.remove(name)
        writePlaylists(o)
    }

    fun addToPlaylist(name: String, t: Track) {
        val o = readPlaylists()
        val list = parseTracks(o.optJSONArray(name) ?: JSONArray())
        if (list.none { key(it) == key(t) }) list.add(t)
        val a = JSONArray()
        list.forEach { a.put(toJson(it)) }
        o.put(name, a)
        writePlaylists(o)
    }

    fun removeFromPlaylist(name: String, t: Track) {
        val o = readPlaylists()
        val list = parseTracks(o.optJSONArray(name) ?: JSONArray())
        list.removeAll { key(it) == key(t) }
        val a = JSONArray()
        list.forEach { a.put(toJson(it)) }
        o.put(name, a)
        writePlaylists(o)
    }
}
