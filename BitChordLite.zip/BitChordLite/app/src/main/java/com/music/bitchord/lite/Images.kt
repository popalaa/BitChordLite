package com.music.bitchord.lite

import android.widget.ImageView
import com.music.bitchord.data.Http
import com.squareup.picasso.OkHttp3Downloader
import com.squareup.picasso.Picasso

/** Album art, loaded through our own OkHttp client so HTTPS works on Android 4.4. */
object Images {
    val picasso: Picasso by lazy {
        Picasso.Builder(Http.appContext)
            .downloader(OkHttp3Downloader(Http.client))
            .build()
    }

    /** [sizePx] > 0 decodes a small, cropped square (lists); 0 loads the picture as is (player). */
    fun load(view: ImageView, url: String?, sizePx: Int = 0) {
        if (url.isNullOrEmpty()) {
            picasso.cancelRequest(view)
            view.setImageResource(R.drawable.art_placeholder)
            return
        }
        var request = picasso.load(url)
            .placeholder(R.drawable.art_placeholder)
            .error(R.drawable.art_placeholder)
        if (sizePx > 0) request = request.resize(sizePx, sizePx).centerCrop()
        request.into(view)
    }
}
