package com.music.bitchord.source

import com.music.bitchord.lite.Library

/** Lists that live on the device (home, library, favorites, downloads, playlists). Not searchable. */
class LocalSource : MusicSource {
    override val id = "local"
    override val name = "Library"

    override fun supports(kind: SearchKind) = false
    override fun search(query: String, kind: SearchKind): ResultPager = EmptyPager
    override fun streamUrl(track: Track): String =
        error("Library entries are played through the source they came from")

    override fun open(item: BrowseEntry): ResultPager = ListPager(entriesFor(item.ref))

    private class ListPager(private val items: List<Entry>) : ResultPager {
        override val hasMore = false
        override fun next(): List<Entry> = items
    }

    private fun entriesFor(ref: String): List<Entry> = when {
        ref == "home" -> home()
        ref == "library" -> library()
        ref == "fav" -> Library.favorites().map { TrackEntry(it) }
        ref == "dl" -> Library.downloads().map { TrackEntry(it) }
        ref == "recent" -> Library.recents().map { TrackEntry(it) }
        ref.startsWith("pl:") -> Library.playlist(ref.removePrefix("pl:")).map { TrackEntry(it) }
        else -> emptyList()
    }

    // Ready-made searches: (label shown, text searched).
    private val presets = listOf(
        "Arabic hits" to "أغاني عربية جديدة",
        "Top English hits" to "top english songs 2026",
        "عمرو دياب" to "عمرو دياب",
        "أم كلثوم" to "أم كلثوم",
        "Rap" to "rap hits",
        "Chill" to "chill songs",
        "Workout" to "workout music",
        "Classical Arabic" to "طرب كلاسيكي",
    )

    private fun home(): List<Entry> {
        val out = ArrayList<Entry>()
        val recents = Library.recents().take(10)
        if (recents.isNotEmpty()) {
            out.add(HeaderEntry("Recently played"))
            recents.forEach { out.add(TrackEntry(it)) }
        }
        out.add(HeaderEntry("Quick picks"))
        presets.forEach { (label, query) ->
            out.add(BrowseEntry(BrowseKind.PRESET, label, "Search songs", query, id))
        }
        return out
    }

    private fun library(): List<Entry> {
        fun row(title: String, ref: String, tracks: List<Track>) = BrowseEntry(
            BrowseKind.LIST, title, "${tracks.size} songs", ref, id, tracks.firstOrNull()?.artworkUrl
        )
        val out = ArrayList<Entry>()
        out.add(row("Favorites", "fav", Library.favorites()))
        out.add(row("Downloads", "dl", Library.downloads()))
        out.add(row("Recently played", "recent", Library.recents()))
        val names = Library.playlistNames()
        if (names.isNotEmpty()) out.add(HeaderEntry("Playlists"))
        names.forEach { out.add(row(it, "pl:$it", Library.playlist(it))) }
        out.add(BrowseEntry(BrowseKind.LIST, "New playlist...", "", "new", id))
        return out
    }
}
