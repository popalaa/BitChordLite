package com.music.bitchord.source

import com.music.bitchord.data.Http
import okhttp3.HttpUrl
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

/**
 * Audius (https://audius.co): an open, free music network with a public REST API.
 * Artists must be credited, which the UI does by always showing the artist name.
 */
class AudiusSource : MusicSource {
    override val id = "audius"
    override val name = "Audius"

    // Tried in order; the first one that answers is used.
    private val bases = listOf("https://api.audius.co", "https://discoveryprovider.audius.co")

    override fun search(query: String): List<Track> {
        val json = get("/v1/tracks/search") { it.addQueryParameter("query", query).addQueryParameter("limit", "25") }
        val data = json.optJSONArray("data") ?: return emptyList()
        val out = ArrayList<Track>(data.length())
        for (i in 0 until data.length()) {
            val o = data.getJSONObject(i)
            val id = o.optString("id")
            if (id.isEmpty()) continue
            out += Track(
                id = id,
                title = o.optString("title", "?"),
                artist = o.optJSONObject("user")?.optString("name").orEmpty(),
                durationSec = o.optInt("duration"),
            )
        }
        return out
    }

    override fun streamUrl(track: Track): String {
        // no_redirect=true makes the API answer with the final audio URL as JSON.
        val json = get("/v1/tracks/${track.id}/stream") { it.addQueryParameter("no_redirect", "true") }
        return json.optString("data").ifEmpty { throw IOException("Audius returned no stream URL") }
    }

    private fun get(path: String, params: (HttpUrl.Builder) -> HttpUrl.Builder): JSONObject {
        var last: Exception? = null
        for (base in bases) {
            try {
                val url = params(HttpUrl.parse(base + path)!!.newBuilder())
                    .addQueryParameter("app_name", "BitChordLite")
                    .build()
                Http.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("HTTP ${r.code()} from ${url.host()}")
                    return JSONObject(r.body()?.string() ?: throw IOException("Empty response"))
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("No Audius host answered")
    }
}
