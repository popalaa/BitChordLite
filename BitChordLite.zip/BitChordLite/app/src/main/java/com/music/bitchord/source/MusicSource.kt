package com.music.bitchord.source

/** A playable song. */
data class Track(
    /** Meaning depends on the source (YouTube video URL). */
    val id: String,
    val title: String,
    val artist: String,
    val durationSec: Int,
    /** Which [MusicSource] can resolve this track. */
    val sourceId: String = "youtube",
    val artworkUrl: String? = null,
)

enum class BrowseKind { ALBUM, ARTIST }

/** One row in a result list: either something to play or something to open. */
sealed class Entry
data class TrackEntry(val track: Track) : Entry()
data class BrowseEntry(
    val kind: BrowseKind,
    val title: String,
    val subtitle: String,
    /** Source-specific reference (a URL for YouTube). */
    val ref: String,
    val sourceId: String,
    val artworkUrl: String? = null,
) : Entry()

enum class SearchKind(val label: String) {
    SONGS("Songs"), ALBUMS("Albums"), ARTISTS("Artists"), VIDEOS("Videos")
}

/** Pages of results. [next] is blocking: call it from a background thread. */
interface ResultPager {
    val hasMore: Boolean
    fun next(): List<Entry>
}

object EmptyPager : ResultPager {
    override val hasMore = false
    override fun next(): List<Entry> = emptyList()
}

/** Where songs come from. Swap implementations without touching the UI or the player. */
interface MusicSource {
    val id: String
    val name: String

    /** Whether [kind] is something this source can search for. */
    fun supports(kind: SearchKind): Boolean

    fun search(query: String, kind: SearchKind): ResultPager

    /** Opens an album or artist found by [search]. */
    fun open(item: BrowseEntry): ResultPager

    /** Blocking: returns a URL ExoPlayer can play directly. */
    fun streamUrl(track: Track): String
}

object Sources {
    val all: List<MusicSource> by lazy { listOf(YouTubeSource()) }
    fun byId(id: String): MusicSource = all.firstOrNull { it.id == id } ?: all.first()
}

/** "Class: message" for the throwable and up to two causes, for showing on screen. */
fun describe(t: Throwable): String {
    val parts = ArrayList<String>()
    var c: Throwable? = t
    while (c != null && parts.size < 3) {
        parts += "${c.javaClass.simpleName}: ${c.message}"
        c = c.cause
    }
    return parts.joinToString("\n")
}
