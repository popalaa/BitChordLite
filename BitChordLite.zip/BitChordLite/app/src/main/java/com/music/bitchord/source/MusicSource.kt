package com.music.bitchord.source

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val durationSec: Int,
)

/** Where songs come from. Swap implementations without touching the UI or the player. */
interface MusicSource {
    val name: String

    /** Blocking: call from a background thread. */
    fun search(query: String): List<Track>

    /** Blocking: returns a URL ExoPlayer can play directly. */
    fun streamUrl(track: Track): String
}
