package com.music.bitchord.source

data class Track(
    /** Meaning depends on the source (Audius track id, YouTube video URL, ...). */
    val id: String,
    val title: String,
    val artist: String,
    val durationSec: Int,
    /** Which [MusicSource] can resolve this track. */
    val sourceId: String = "audius",
)

/** Where songs come from. Swap implementations without touching the UI or the player. */
interface MusicSource {
    val id: String
    val name: String

    /** Blocking: call from a background thread. */
    fun search(query: String): List<Track>

    /** Blocking: returns a URL ExoPlayer can play directly. */
    fun streamUrl(track: Track): String
}

object Sources {
    val all: List<MusicSource> by lazy { listOf(YouTubeSource(), AudiusSource()) }
    fun byId(id: String): MusicSource = all.firstOrNull { it.id == id } ?: all.first()
}

/** "Class: message" for the throwable and up to two causes, for showing on screen. */
fun describe(t: Throwable): String {
    val parts = ArrayList<String>()
    var c: Throwable? = t
    while (c != null && parts.size < 3) {
        parts += "${c.javaClass.simpleName}: ${c.message}"
        c = c.cause
    }
    return parts.joinToString("\n")
}
