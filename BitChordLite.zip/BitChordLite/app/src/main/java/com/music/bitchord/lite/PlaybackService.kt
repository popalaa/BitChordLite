package com.music.bitchord.lite

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.audio.AudioAttributes
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.music.bitchord.source.AudiusSource
import com.music.bitchord.source.MusicSource
import com.music.bitchord.source.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Owns the player and the queue, so music keeps playing when the screen is closed.
 * The activity binds to it to read state and send commands; everything runs on the main thread.
 */
class PlaybackService : Service() {
    companion object {
        const val ACTION_PLAY_PAUSE = "com.music.bitchord.lite.PLAY_PAUSE"
        const val ACTION_NEXT = "com.music.bitchord.lite.NEXT"
        const val ACTION_PREV = "com.music.bitchord.lite.PREV"
        const val ACTION_STOP = "com.music.bitchord.lite.STOP"
        private const val CHANNEL_ID = "playback"
        private const val NOTIF_ID = 1
    }

    inner class LocalBinder : Binder() {
        fun service(): PlaybackService = this@PlaybackService
    }

    private val binder = LocalBinder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val source: MusicSource = AudiusSource()
    private lateinit var player: ExoPlayer
    private lateinit var nm: NotificationManager
    private var loadJob: Job? = null
    private var inForeground = false

    private val tracks = ArrayList<Track>()
    val queue: List<Track> get() = tracks
    var index = -1
        private set
    val current: Track? get() = tracks.getOrNull(index)

    /** Short text for the UI: buffering, errors, etc. Empty when all is fine. */
    var status = ""
        private set
    var onChange: (() -> Unit)? = null

    val isPlaying: Boolean get() = player.isPlaying
    val positionMs: Long get() = player.currentPosition
    val durationMs: Long get() = player.duration // negative while unknown

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Playback", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("BitChordLite/0.2")
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            /* handleAudioFocus = */ true
        )
        player.setHandleAudioBecomingNoisy(true)
        player.setWakeMode(C.WAKE_MODE_NETWORK)
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> status = "Buffering..."
                    Player.STATE_READY -> status = ""
                    Player.STATE_ENDED -> if (index + 1 < tracks.size) next() else status = "Finished"
                    else -> {}
                }
                refreshNotification(); changed()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                refreshNotification(); changed()
            }

            override fun onPlayerError(error: PlaybackException) {
                val parts = ArrayList<String>()
                var c: Throwable? = error
                while (c != null && parts.size < 3) { parts += "${c.javaClass.simpleName}: ${c.message}"; c = c.cause }
                status = "Playback error: ${error.errorCodeName}\n" + parts.joinToString("\n")
                refreshNotification(); changed()
            }
        })
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> togglePlay()
            ACTION_NEXT -> next()
            ACTION_PREV -> previous()
            ACTION_STOP -> stopPlayback()
            // Plain start from the activity: become a foreground service right away.
            else -> enterForeground(buildNotification())
        }
        return START_NOT_STICKY
    }

    // ---- commands -----------------------------------------------------------------------

    fun playTracks(list: List<Track>, startIndex: Int) {
        tracks.clear(); tracks.addAll(list)
        playIndex(startIndex)
    }

    fun addToQueue(track: Track) {
        tracks.add(track)
        if (index < 0) playIndex(tracks.lastIndex) else changed()
    }

    fun playIndex(i: Int) {
        if (i !in tracks.indices) return
        index = i
        val track = tracks[i]
        status = "Loading..."
        player.stop()
        loadJob?.cancel()
        loadJob = scope.launch {
            try {
                val url = withContext(Dispatchers.IO) { source.streamUrl(track) }
                player.setMediaItem(MediaItem.fromUri(url))
                player.prepare()
                player.play()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                status = "Could not start: ${t.javaClass.simpleName}: ${t.message}"
                refreshNotification(); changed()
            }
        }
        refreshNotification(); changed()
    }

    fun next() { if (index + 1 < tracks.size) playIndex(index + 1) }

    fun previous() {
        if (player.currentPosition > 3000 || index <= 0) player.seekTo(0) else playIndex(index - 1)
    }

    fun togglePlay() {
        if (player.currentMediaItem == null) {
            if (current != null) playIndex(index)
            return
        }
        if (player.isPlaying) player.pause() else player.play()
    }

    fun seekTo(ms: Long) = player.seekTo(ms)

    private fun stopPlayback() {
        loadJob?.cancel()
        player.stop()
        player.clearMediaItems()
        status = ""
        stopForeground(true)
        inForeground = false
        nm.cancel(NOTIF_ID)
        changed()
        stopSelf()
    }

    // ---- notification -------------------------------------------------------------------

    private fun changed() { onChange?.invoke() }

    private fun refreshNotification() {
        if (current == null) return
        val active = player.isPlaying || player.playbackState == Player.STATE_BUFFERING || loadJob?.isActive == true
        val n = buildNotification()
        if (active) {
            enterForeground(n)
        } else {
            if (inForeground) { stopForeground(false); inForeground = false }
            nm.notify(NOTIF_ID, n)
        }
    }

    private fun enterForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        inForeground = true
    }

    private fun pendingFlags() =
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    private fun action(icon: Int, title: String, act: String): NotificationCompat.Action {
        val pi = PendingIntent.getService(
            this, act.hashCode(), Intent(this, PlaybackService::class.java).setAction(act), pendingFlags()
        )
        return NotificationCompat.Action(icon, title, pi)
    }

    private fun buildNotification(): Notification {
        val t = current
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            pendingFlags()
        )
        val playing = player.isPlaying
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(t?.title ?: "BitChord Lite")
            .setContentText(if (t != null) t.artist else "Starting...")
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(action(android.R.drawable.ic_media_previous, "Previous", ACTION_PREV))
            .addAction(
                action(
                    if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                    if (playing) "Pause" else "Play", ACTION_PLAY_PAUSE
                )
            )
            .addAction(action(android.R.drawable.ic_media_next, "Next", ACTION_NEXT))
            .addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "Stop", ACTION_STOP))
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        player.release()
        super.onDestroy()
    }
}
