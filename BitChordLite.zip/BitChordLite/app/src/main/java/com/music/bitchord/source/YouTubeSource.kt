package com.music.bitchord.source

import com.music.bitchord.yt.Cursor
import com.music.bitchord.yt.YouTube
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.stream.StreamInfoItem

/** Official songs, albums and famous artists (Arabic and international) from YouTube Music. Unofficial. */
class YouTubeSource : MusicSource {
    override val id = "youtube"
    override val name = "YouTube Music"

    override fun supports(kind: SearchKind) = true

    override fun search(query: String, kind: SearchKind): ResultPager {
        val filter = when (kind) {
            SearchKind.SONGS -> YouTube.songs
            SearchKind.ALBUMS -> YouTube.albums
            SearchKind.ARTISTS -> YouTube.artists
            SearchKind.VIDEOS -> YouTube.videos
        }
        return CursorPager(YouTube.search(query, filter))
    }

    override fun open(item: BrowseEntry): ResultPager = when (item.kind) {
        // A real artist page needs more of YouTube Music's internals; searching the
        // artist's name among songs gives their tracks, and the Albums button their albums.
        BrowseKind.ARTIST -> search(item.title, SearchKind.SONGS)
        BrowseKind.ALBUM -> CursorPager(YouTube.playlist(item.ref))
    }

    override fun streamUrl(track: Track): String = YouTube.audioUrl(track.id)

    private inner class CursorPager(private val cursor: Cursor) : ResultPager {
        override val hasMore: Boolean get() = cursor.hasMore
        override fun next(): List<Entry> = cursor.next().mapNotNull { toEntry(it) }
    }

    private fun toEntry(item: InfoItem): Entry? = when (item) {
        is StreamInfoItem -> TrackEntry(
            Track(
                id = item.url,
                title = item.name ?: "?",
                artist = item.uploaderName ?: "",
                durationSec = item.duration.coerceIn(0, Int.MAX_VALUE.toLong()).toInt(),
                sourceId = id,
                artworkUrl = pickArt(item.thumbnails),
            )
        )
        is PlaylistInfoItem -> BrowseEntry(
            kind = BrowseKind.ALBUM,
            title = item.name ?: "?",
            subtitle = listOfNotNull(
                item.uploaderName?.takeIf { it.isNotBlank() },
                item.streamCount.takeIf { it >= 0 }?.let { "$it songs" },
            ).joinToString(" · "),
            ref = item.url,
            sourceId = id,
            artworkUrl = pickArt(item.thumbnails),
        )
        is ChannelInfoItem -> BrowseEntry(
            kind = BrowseKind.ARTIST,
            title = item.name ?: "?",
            subtitle = item.subscriberCount.takeIf { it >= 0 }?.let { "$it subscribers" }.orEmpty(),
            ref = item.url,
            sourceId = id,
            artworkUrl = pickArt(item.thumbnails),
        )
        else -> null
    }

    /** The biggest thumbnail that is still light enough for an old phone. */
    private fun pickArt(images: List<Image>?): String? {
        if (images.isNullOrEmpty()) return null
        val light = images.filter { it.height in 1..700 }
        return (light.maxByOrNull { it.height } ?: images.first()).url
    }
}
