package com.music.bitchord.source

import com.music.bitchord.yt.YouTube

/** Official songs and famous artists (Arabic and international) from YouTube Music. Unofficial. */
class YouTubeSource : MusicSource {
    override val id = "youtube"
    override val name = "YouTube Music"

    override fun search(query: String): List<Track> =
        YouTube.searchSongs(query).map {
            Track(
                id = it.url,
                title = it.title,
                artist = it.artist,
                durationSec = it.durationSec.coerceIn(0, Int.MAX_VALUE.toLong()).toInt(),
                sourceId = id,
            )
        }

    override fun streamUrl(track: Track): String = YouTube.audioUrl(track.id)
}
