package com.music.bitchord.lite

import android.app.Application
import androidx.multidex.MultiDex
import android.content.Context
import org.conscrypt.Conscrypt
import java.security.Security

class LiteApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    override fun onCreate() {
        super.onCreate()
        // Android 4.4's own TLS is too old for most servers today.
        runCatching { Security.insertProviderAt(Conscrypt.newProvider(), 1) }
    }
}
