package com.music.bitchord.lite

import android.app.Application
import android.content.Context
import androidx.multidex.MultiDex
import com.music.bitchord.data.Http

class LiteApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    override fun onCreate() {
        super.onCreate()
        Http.appContext = applicationContext
        Library.init(applicationContext)
        Downloads.init(applicationContext)
        // Build the TLS setup off the main thread (parsing ~140 certificates is slow on old
        // devices). Http.client is a synchronized lazy, so anything that needs it simply waits.
        Thread { Http.client; Images.picasso }.start()
    }
}
