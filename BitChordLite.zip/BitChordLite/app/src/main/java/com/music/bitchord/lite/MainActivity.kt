package com.music.bitchord.lite

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.music.bitchord.data.Http
import com.music.bitchord.data.lyrics.LrcLib
import com.music.bitchord.data.lyrics.LyricLine
import com.music.bitchord.source.BrowseEntry
import com.music.bitchord.source.BrowseKind
import com.music.bitchord.source.Entry
import com.music.bitchord.source.MusicSource
import com.music.bitchord.source.ResultPager
import com.music.bitchord.source.SearchKind
import com.music.bitchord.source.Sources
import com.music.bitchord.source.Track
import com.music.bitchord.source.TrackEntry
import com.music.bitchord.source.describe
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.util.Locale

/** Search, browse albums and artists, queue, lyrics and a full-screen player. Music plays in PlaybackService. */
class MainActivity : AppCompatActivity() {
    private enum class Tab { RESULTS, QUEUE }

    /** One screen of results in the Back stack. */
    private class ViewState(val label: String, val pager: ResultPager, val entries: ArrayList<Entry>)

    private val accent = 0xFF8B7CFF.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val gray = 0xFFA0A0AA.toInt()

    private val source: MusicSource = Sources.all.first() // YouTube Music
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var searchJob: Job? = null
    private var moreJob: Job? = null
    private var lyricsJob: Job? = null

    private var service: PlaybackService? = null
    private var bound = false
    private val ui = Handler(Looper.getMainLooper())
    private var dragging = false

    private var tab = Tab.RESULTS
    private var kind = SearchKind.SONGS
    private var lastQuery = ""
    private var message = "Search for a song, an artist or an album."
    private val stack = ArrayList<ViewState>()
    private val shown = ArrayList<Entry>()

    // what is playing (to know when the artwork and lyrics must change)
    private var playingKey: String? = null
    private var lyricLines: List<LyricLine> = emptyList()
    private var lyricsNote = "Nothing playing."
    private var lyricIndex = -1
    private val lyricTexts = ArrayList<String>()
    private var lyricsOn = false

    private lateinit var adapter: ArrayAdapter<Entry>
    private lateinit var lyricAdapter: ArrayAdapter<String>
    private lateinit var list: ListView
    private lateinit var lyricsList: ListView
    private lateinit var footer: TextView
    private lateinit var query: EditText
    private lateinit var status: TextView
    private lateinit var viewTitle: TextView
    private lateinit var backBtn: TextView
    private lateinit var tabViews: Map<Tab, TextView>
    private lateinit var kindChips: Map<SearchKind, TextView>

    // mini player
    private lateinit var miniPanel: LinearLayout
    private lateinit var miniArt: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlay: ImageButton
    private lateinit var miniProgress: ProgressBar

    // full player
    private lateinit var playerPanel: LinearLayout
    private lateinit var pArt: ImageView
    private lateinit var pTitle: TextView
    private lateinit var pArtist: TextView
    private lateinit var pLyricsBtn: TextView
    private lateinit var pPlay: ImageButton
    private lateinit var seek: SeekBar
    private lateinit var timeCur: TextView
    private lateinit var timeTotal: TextView

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = (binder as PlaybackService.LocalBinder).service()
            service = s
            s.onChange = { render() }
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) { service = null }
    }

    private val ticker = object : Runnable {
        override fun run() { tick(); ui.postDelayed(this, 500) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        viewTitle = findViewById(R.id.viewTitle)
        backBtn = findViewById(R.id.backBtn)
        query = findViewById(R.id.query)
        list = findViewById(R.id.results)
        lyricsList = findViewById(R.id.pLyrics)
        miniPanel = findViewById(R.id.miniPanel)
        miniArt = findViewById(R.id.miniArt)
        miniTitle = findViewById(R.id.miniTitle)
        miniArtist = findViewById(R.id.miniArtist)
        miniPlay = findViewById(R.id.miniPlay)
        miniProgress = findViewById(R.id.miniProgress)
        playerPanel = findViewById(R.id.playerPanel)
        pArt = findViewById(R.id.pArt)
        pTitle = findViewById(R.id.pTitle)
        pArtist = findViewById(R.id.pArtist)
        pLyricsBtn = findViewById(R.id.pLyricsBtn)
        pPlay = findViewById(R.id.playPause)
        seek = findViewById(R.id.seek)
        timeCur = findViewById(R.id.timeCur)
        timeTotal = findViewById(R.id.timeTotal)
        tabViews = mapOf(
            Tab.RESULTS to findViewById<TextView>(R.id.tabResults),
            Tab.QUEUE to findViewById<TextView>(R.id.tabQueue),
        )
        kindChips = mapOf(
            SearchKind.SONGS to findViewById<TextView>(R.id.kSongs),
            SearchKind.ALBUMS to findViewById<TextView>(R.id.kAlbums),
            SearchKind.ARTISTS to findViewById<TextView>(R.id.kArtists),
            SearchKind.VIDEOS to findViewById<TextView>(R.id.kVideos),
        )

        adapter = object : ArrayAdapter<Entry>(this, R.layout.item_track, R.id.t_title, shown) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = super.getView(position, convertView, parent)
                val art = row.findViewById<ImageView>(R.id.t_art)
                val title = row.findViewById<TextView>(R.id.t_title)
                val sub = row.findViewById<TextView>(R.id.t_sub)
                val s = service
                when (val e = getItem(position)!!) {
                    is TrackEntry -> {
                        val t = e.track
                        val cur = s?.current
                        val isCurrent = cur != null &&
                            (if (tab == Tab.QUEUE) position == s?.index else t.id == cur.id && t.sourceId == cur.sourceId)
                        title.text = t.title
                        title.setTextColor(if (isCurrent) accent else white)
                        sub.text = "${t.artist}  ·  ${fmt(t.durationSec * 1000L)}"
                        Images.load(art, t.artworkUrl, dp(52))
                    }
                    is BrowseEntry -> {
                        val label = if (e.kind == BrowseKind.ALBUM) "Album" else "Artist"
                        title.text = e.title
                        title.setTextColor(white)
                        sub.text = listOf(label, e.subtitle).filter { it.isNotBlank() }.joinToString("  ·  ")
                        Images.load(art, e.artworkUrl, dp(52))
                    }
                }
                return row
            }
        }
        lyricAdapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lyricTexts) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getView(position, convertView, parent) as TextView
                val current = position == lyricIndex
                tv.textSize = 20f
                tv.gravity = Gravity.CENTER
                tv.setTextColor(if (current) white else 0xFF6E6E78.toInt())
                tv.setTypeface(null, if (current) Typeface.BOLD else Typeface.NORMAL)
                return tv
            }
        }
        lyricsList.adapter = lyricAdapter

        footer = TextView(this).apply {
            text = "Load more"
            gravity = Gravity.CENTER
            setTextColor(accent)
            textSize = 15f
            setPadding(0, dp(14), 0, dp(14))
            visibility = View.GONE
            setOnClickListener { loadMore() }
        }
        list.addFooterView(footer, null, false)
        list.adapter = adapter
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView, scrollState: Int) {}
            override fun onScroll(view: AbsListView, first: Int, visible: Int, total: Int) {
                if (tab == Tab.RESULTS && total > 0 && first + visible >= total - 2) loadMore()
            }
        })
        list.setOnItemClickListener { _, _, position, _ -> onRowClick(position) }
        list.setOnItemLongClickListener { _, _, position, _ ->
            val e = shown.getOrNull(position)
            if (tab == Tab.RESULTS && e is TrackEntry) {
                withService { it.addToQueue(e.track) }
                Toast.makeText(this, "Added to queue", Toast.LENGTH_SHORT).show()
            }
            true
        }
        lyricsList.setOnItemClickListener { _, _, position, _ ->
            lyricLines.getOrNull(position)?.let { service?.seekTo(it.timeMs) }
        }

        findViewById<View>(R.id.search).setOnClickListener { search(query.text.toString()) }
        query.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                search(query.text.toString()); true
            } else false
        }
        for ((k, chip) in kindChips) chip.setOnClickListener { selectKind(k) }
        for ((t, v) in tabViews) v.setOnClickListener { tab = t; render() }
        backBtn.setOnClickListener { goBack() }
        findViewById<View>(R.id.diag).setOnClickListener { runDiagnostics() }

        // mini player opens the full player; controls
        miniPanel.setOnClickListener { setPlayerOpen(true) }
        miniPlay.setOnClickListener { withService { it.togglePlay() } }
        pPlay.setOnClickListener { withService { it.togglePlay() } }
        findViewById<View>(R.id.prev).setOnClickListener { withService { it.previous() } }
        findViewById<View>(R.id.next).setOnClickListener { withService { it.next() } }
        findViewById<View>(R.id.pClose).setOnClickListener { setPlayerOpen(false) }
        findViewById<View>(R.id.pQueueBtn).setOnClickListener {
            setPlayerOpen(false); tab = Tab.QUEUE; render()
        }
        pLyricsBtn.setOnClickListener { lyricsOn = !lyricsOn; render() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) timeCur.text = fmt(progress.toLong())
            }

            override fun onStartTrackingTouch(bar: SeekBar) { dragging = true }

            override fun onStopTrackingTouch(bar: SeekBar) {
                service?.seekTo(bar.progress.toLong())
                dragging = false
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!goBack()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        render()
    }

    override fun onStart() {
        super.onStart()
        bound = bindService(Intent(this, PlaybackService::class.java), connection, Context.BIND_AUTO_CREATE)
        ui.post(ticker)
    }

    override fun onStop() {
        ui.removeCallbacks(ticker)
        service?.onChange = null
        if (bound) { unbindService(connection); bound = false }
        service = null
        super.onStop()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ---- navigation ---------------------------------------------------------------------

    private fun setPlayerOpen(open: Boolean) {
        playerPanel.visibility = if (open) View.VISIBLE else View.GONE
        if (open) tick()
    }

    private fun goBack(): Boolean {
        if (playerPanel.visibility == View.VISIBLE) { setPlayerOpen(false); return true }
        if (tab != Tab.RESULTS) { tab = Tab.RESULTS; render(); return true }
        if (stack.size > 1) { stack.removeAt(stack.lastIndex); render(); return true }
        return false
    }

    private fun onRowClick(position: Int) {
        when (tab) {
            Tab.QUEUE -> if (position < shown.size) withService { it.playIndex(position) }
            Tab.RESULTS -> when (val e = shown.getOrNull(position)) {
                is TrackEntry -> {
                    val tracks = shown.filterIsInstance<TrackEntry>().map { it.track }
                    val start = tracks.indexOf(e.track).coerceAtLeast(0)
                    withService { it.playTracks(tracks, start) }
                }
                is BrowseEntry -> openEntry(e)
                null -> {}
            }
        }
    }

    private fun openEntry(e: BrowseEntry) {
        val src = Sources.byId(e.sourceId)
        if (e.kind == BrowseKind.ARTIST) {
            // The chips now search for this artist's name (Songs / Albums / Videos).
            lastQuery = e.title
            query.setText(e.title)
            kind = SearchKind.SONGS
        }
        val label = (if (e.kind == BrowseKind.ALBUM) "Album: " else "Artist: ") + e.title
        openView(label, replace = false) { src.open(e) }
    }

    private fun selectKind(k: SearchKind) {
        kind = k
        val q = lastQuery.ifEmpty { query.text.toString().trim() }
        if (q.isNotEmpty()) search(q) else render()
    }

    private fun search(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        lastQuery = q
        tab = Tab.RESULTS
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(query.windowToken, 0)
        val src = source
        val k = kind
        openView("${k.label}: $q", replace = true) { src.search(q, k) }
    }

    /** Loads the first page off the main thread, then shows it as a new screen. */
    private fun openView(label: String, replace: Boolean, create: () -> ResultPager) {
        setMessage("Loading...")
        searchJob?.cancel()
        moreJob?.cancel()
        searchJob = scope.launch {
            try {
                val (pager, first) = withContext(Dispatchers.IO) {
                    val p = create()
                    p to p.next()
                }
                if (replace) stack.clear()
                stack.add(ViewState(label, pager, ArrayList(first)))
                tab = Tab.RESULTS
                message = if (first.isEmpty()) "Nothing found in ${source.name} for this." else
                    "Tap a song to play it, long-press to queue it."
                render()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                setMessage("Failed:\n" + describe(t))
            }
        }
    }

    private fun loadMore() {
        val v = stack.lastOrNull() ?: return
        if (!v.pager.hasMore || moreJob?.isActive == true || searchJob?.isActive == true) return
        footer.text = "Loading..."
        moreJob = scope.launch {
            try {
                val more = withContext(Dispatchers.IO) { v.pager.next() }
                v.entries.addAll(more)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                message = "Could not load more:\n" + describe(t)
            }
            footer.text = "Load more"
            render()
        }
    }

    // ---- lyrics -------------------------------------------------------------------------

    private fun loadLyrics(track: Track?) {
        lyricsJob?.cancel()
        lyricLines = emptyList()
        lyricIndex = -1
        if (track == null) {
            lyricsNote = "Nothing playing."
            rebuildLyrics()
            return
        }
        lyricsNote = "Loading lyrics..."
        rebuildLyrics()
        lyricsJob = scope.launch {
            val lines = try {
                LrcLib.lyrics(track.title, track.artist, track.durationSec * 1000L)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                null
            }
            lyricLines = lines.orEmpty().filter { it.text.isNotBlank() }
            lyricsNote = if (lyricLines.isEmpty()) "No synced lyrics found for this song." else ""
            rebuildLyrics()
        }
    }

    private fun rebuildLyrics() {
        lyricTexts.clear()
        if (lyricLines.isEmpty()) lyricTexts.add(lyricsNote) else lyricLines.forEach { lyricTexts.add(it.text) }
        lyricAdapter.notifyDataSetChanged()
    }

    // ---- helpers ------------------------------------------------------------------------

    /** Makes sure the service runs in the foreground (so it survives closing the app), then runs [block]. */
    private fun withService(block: (PlaybackService) -> Unit) {
        val s = service
        if (s == null) {
            setMessage("Player is not ready yet, try again in a second.")
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, PlaybackService::class.java))
        block(s)
    }

    private fun setMessage(text: String) {
        message = text
        render()
    }

    private fun fmt(ms: Long): String =
        String.format(Locale.US, "%d:%02d", ms / 60000, (ms / 1000) % 60)

    private fun render() {
        val s = service
        val cur = s?.current
        val playing = s != null && s.isPlaying

        miniPanel.visibility = if (cur != null) View.VISIBLE else View.GONE
        miniTitle.text = cur?.title ?: ""
        miniArtist.text = cur?.artist ?: ""
        pTitle.text = cur?.title ?: "Nothing playing"
        pArtist.text = cur?.artist ?: ""
        val icon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        miniPlay.setImageResource(icon)
        pPlay.setImageResource(icon)
        status.text = if (s != null && s.status.isNotEmpty()) s.status else message

        // artwork and lyrics only change when the song does
        val key = cur?.let { "${it.sourceId}:${it.id}" }
        if (key != playingKey) {
            playingKey = key
            Images.load(miniArt, cur?.artworkUrl, dp(44))
            Images.load(pArt, cur?.artworkUrl)
            loadLyrics(cur)
        }

        pArt.visibility = if (lyricsOn) View.GONE else View.VISIBLE
        lyricsList.visibility = if (lyricsOn) View.VISIBLE else View.GONE
        pLyricsBtn.setBackgroundResource(if (lyricsOn) R.drawable.chip_on else R.drawable.chip_off)

        refreshList()
        tick()
    }

    private fun refreshList() {
        shown.clear()
        val current = stack.lastOrNull()
        when (tab) {
            Tab.RESULTS -> if (current != null) shown.addAll(current.entries)
            Tab.QUEUE -> service?.queue?.forEach { shown.add(TrackEntry(it)) }
        }
        adapter.notifyDataSetChanged()

        footer.visibility =
            if (tab == Tab.RESULTS && current?.pager?.hasMore == true) View.VISIBLE else View.GONE
        backBtn.visibility = if (tab == Tab.RESULTS && stack.size > 1) View.VISIBLE else View.GONE
        viewTitle.text = when (tab) {
            Tab.RESULTS -> current?.label ?: ""
            Tab.QUEUE -> "Queue (${shown.size})"
        }
        for ((t, v) in tabViews) {
            v.setTextColor(if (t == tab) white else gray)
            v.setTypeface(null, if (t == tab) Typeface.BOLD else Typeface.NORMAL)
        }
        for ((k, chip) in kindChips) {
            val on = k == kind
            chip.setBackgroundResource(if (on) R.drawable.chip_on else R.drawable.chip_off)
            chip.setTextColor(if (on) 0xFF000000.toInt() else white)
        }
    }

    private fun tick() {
        val s = service ?: return
        val position = s.positionMs.coerceAtLeast(0)
        val duration = if (s.durationMs > 0) s.durationMs else (s.current?.durationSec ?: 0) * 1000L

        // mini progress bar
        if (duration > 0) {
            miniProgress.max = duration.toInt()
            miniProgress.progress = position.coerceAtMost(duration).toInt()
        } else {
            miniProgress.max = 1; miniProgress.progress = 0
        }

        // current lyric line
        if (lyricLines.isNotEmpty()) {
            val idx = lyricLines.indexOfLast { it.timeMs <= position + 300 }
            if (idx != lyricIndex) {
                lyricIndex = idx
                lyricAdapter.notifyDataSetChanged()
                if (lyricsOn && idx >= 0) lyricsList.setSelectionFromTop(idx, lyricsList.height / 3)
            }
        }

        // full player seek bar
        if (dragging || playerPanel.visibility != View.VISIBLE) return
        if (duration > 0) {
            seek.max = duration.toInt()
            seek.progress = position.coerceAtMost(duration).toInt()
            timeTotal.text = fmt(duration)
        } else {
            seek.max = 1; seek.progress = 0; timeTotal.text = "--:--"
        }
        timeCur.text = fmt(position)
    }

    private fun runDiagnostics() {
        setMessage("Testing...")
        searchJob?.cancel()
        searchJob = scope.launch {
            val report = withContext(Dispatchers.IO) {
                val sb = StringBuilder("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.CPU_ABI}\n")
                sb.append("TLS setup: ${Http.tlsSetupError ?: "ok"}\n")
                for (url in listOf(
                    "https://www.youtube.com/",
                    "https://music.youtube.com/",
                    "https://lrclib.net/api/search?q=test",
                )) {
                    sb.append(url.substringBefore("?")).append(" -> ")
                    try {
                        Http.client.newCall(Request.Builder().url(url).build()).execute().use { sb.append("HTTP ${it.code()}") }
                    } catch (t: Throwable) {
                        sb.append("${t.javaClass.simpleName}: ${t.message}")
                    }
                    sb.append('\n')
                }
                sb.toString()
            }
            setMessage(report)
        }
    }
}
