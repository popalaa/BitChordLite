package com.music.bitchord.lite

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.music.bitchord.data.lyrics.LrcLib
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Smoke test: proves the ported LrcLib + LRC parser run on the device. */
class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val title = findViewById<EditText>(R.id.title)
        val artist = findViewById<EditText>(R.id.artist)
        val out = findViewById<TextView>(R.id.out)
        findViewById<Button>(R.id.go).setOnClickListener {
            out.text = "..."
            job?.cancel()
            job = scope.launch {
                val lines = LrcLib.lyrics(title.text.toString(), artist.text.toString(), 0L)
                out.text = if (lines == null) "No synced lyrics found (or the network failed)."
                else lines.take(12).joinToString("\n") { "${it.timeMs / 1000}s  ${it.text}" }
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
