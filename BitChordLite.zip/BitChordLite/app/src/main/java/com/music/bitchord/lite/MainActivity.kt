package com.music.bitchord.lite

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.music.bitchord.data.Http
import com.music.bitchord.data.lyrics.LrcLib
import com.music.bitchord.data.lyrics.LyricLine
import com.music.bitchord.source.BrowseEntry
import com.music.bitchord.source.BrowseKind
import com.music.bitchord.source.Entry
import com.music.bitchord.source.HeaderEntry
import com.music.bitchord.source.MusicSource
import com.music.bitchord.source.ResultPager
import com.music.bitchord.source.SearchKind
import com.music.bitchord.source.Sources
import com.music.bitchord.source.Track
import com.music.bitchord.source.TrackEntry
import com.music.bitchord.source.describe
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.util.Locale

/**
 * Home, search, library (favorites, playlists, downloads), queue, lyrics and a full-screen player.
 * The music itself plays in PlaybackService.
 */
class MainActivity : AppCompatActivity() {
    private enum class Tab { RESULTS, QUEUE }

    /** What the bottom of the Back stack is, to highlight the right tab. */
    private enum class Root { HOME, LIBRARY, SEARCH }

    /** One screen of results in the Back stack. [local] is set for lists that live on the device. */
    private class ViewState(
        val label: String,
        val pager: ResultPager,
        val entries: ArrayList<Entry>,
        val local: BrowseEntry? = null,
    )

    private class MenuItem(val label: String, val action: () -> Unit)

    private val accent = 0xFF8B7CFF.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val gray = 0xFFA0A0AA.toInt()

    private val source: MusicSource = Sources.all.first() // YouTube Music
    private val localSource: MusicSource = Sources.byId("local")
    private val homeEntry = BrowseEntry(BrowseKind.LIST, "Home", "", "home", "local")
    private val libraryEntry = BrowseEntry(BrowseKind.LIST, "Library", "", "library", "local")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var searchJob: Job? = null
    private var moreJob: Job? = null
    private var lyricsJob: Job? = null

    private var service: PlaybackService? = null
    private var bound = false
    private val ui = Handler(Looper.getMainLooper())
    private var dragging = false

    private var tab = Tab.RESULTS
    private var root = Root.HOME
    private var kind = SearchKind.SONGS
    private var lastQuery = ""
    private var message = ""
    private val stack = ArrayList<ViewState>()
    private val shown = ArrayList<Entry>()

    // what is playing (to know when the artwork and lyrics must change)
    private var playingKey: String? = null
    private var lyricLines: List<LyricLine> = emptyList()
    private var lyricsNote = "Nothing playing."
    private var lyricIndex = -1
    private val lyricTexts = ArrayList<String>()
    private var lyricsOn = false

    private lateinit var adapter: ArrayAdapter<Entry>
    private lateinit var lyricAdapter: ArrayAdapter<String>
    private lateinit var list: ListView
    private lateinit var lyricsList: ListView
    private lateinit var footer: TextView
    private lateinit var query: EditText
    private lateinit var status: TextView
    private lateinit var viewTitle: TextView
    private lateinit var backBtn: TextView
    private lateinit var tabHome: TextView
    private lateinit var tabLibrary: TextView
    private lateinit var tabQueue: TextView
    private lateinit var kindChips: Map<SearchKind, TextView>

    // mini player
    private lateinit var miniPanel: LinearLayout
    private lateinit var miniArt: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlay: ImageButton
    private lateinit var miniProgress: ProgressBar

    // full player
    private lateinit var playerPanel: LinearLayout
    private lateinit var pArt: ImageView
    private lateinit var pTitle: TextView
    private lateinit var pArtist: TextView
    private lateinit var pLyricsBtn: TextView
    private lateinit var pPlay: ImageButton
    private lateinit var pHeart: ImageButton
    private lateinit var pDownload: ImageButton
    private lateinit var seek: SeekBar
    private lateinit var timeCur: TextView
    private lateinit var timeTotal: TextView

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = (binder as PlaybackService.LocalBinder).service()
            service = s
            s.onChange = { render() }
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) { service = null }
    }

    private val ticker = object : Runnable {
        override fun run() { tick(); ui.postDelayed(this, 500) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        viewTitle = findViewById(R.id.viewTitle)
        backBtn = findViewById(R.id.backBtn)
        query = findViewById(R.id.query)
        list = findViewById(R.id.results)
        lyricsList = findViewById(R.id.pLyrics)
        tabHome = findViewById(R.id.tabHome)
        tabLibrary = findViewById(R.id.tabLibrary)
        tabQueue = findViewById(R.id.tabQueue)
        miniPanel = findViewById(R.id.miniPanel)
        miniArt = findViewById(R.id.miniArt)
        miniTitle = findViewById(R.id.miniTitle)
        miniArtist = findViewById(R.id.miniArtist)
        miniPlay = findViewById(R.id.miniPlay)
        miniProgress = findViewById(R.id.miniProgress)
        playerPanel = findViewById(R.id.playerPanel)
        pArt = findViewById(R.id.pArt)
        pTitle = findViewById(R.id.pTitle)
        pArtist = findViewById(R.id.pArtist)
        pLyricsBtn = findViewById(R.id.pLyricsBtn)
        pPlay = findViewById(R.id.playPause)
        pHeart = findViewById(R.id.pHeart)
        pDownload = findViewById(R.id.pDownload)
        seek = findViewById(R.id.seek)
        timeCur = findViewById(R.id.timeCur)
        timeTotal = findViewById(R.id.timeTotal)
        kindChips = mapOf(
            SearchKind.SONGS to findViewById<TextView>(R.id.kSongs),
            SearchKind.ALBUMS to findViewById<TextView>(R.id.kAlbums),
            SearchKind.ARTISTS to findViewById<TextView>(R.id.kArtists),
            SearchKind.VIDEOS to findViewById<TextView>(R.id.kVideos),
        )

        adapter = object : ArrayAdapter<Entry>(this, R.layout.item_track, R.id.t_title, shown) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = super.getView(position, convertView, parent)
                val art = row.findViewById<ImageView>(R.id.t_art)
                val title = row.findViewById<TextView>(R.id.t_title)
                val sub = row.findViewById<TextView>(R.id.t_sub)
                val s = service
                // rows are recycled, so every branch sets everything it depends on
                art.visibility = View.VISIBLE
                sub.visibility = View.VISIBLE
                title.textSize = 16f
                title.setTypeface(null, Typeface.NORMAL)
                when (val e = getItem(position)!!) {
                    is HeaderEntry -> {
                        art.visibility = View.GONE
                        sub.visibility = View.GONE
                        title.text = e.title
                        title.textSize = 14f
                        title.setTypeface(null, Typeface.BOLD)
                        title.setTextColor(gray)
                    }
                    is TrackEntry -> {
                        val t = e.track
                        val cur = s?.current
                        val isCurrent = cur != null &&
                            (if (tab == Tab.QUEUE) position == s?.index else t.id == cur.id && t.sourceId == cur.sourceId)
                        title.text = t.title
                        title.setTextColor(if (isCurrent) accent else white)
                        val downloaded = if (Downloads.has(t)) "  ·  Downloaded" else ""
                        sub.text = "${t.artist}  ·  ${fmt(t.durationSec * 1000L)}$downloaded"
                        Images.load(art, t.artworkUrl, dp(52))
                    }
                    is BrowseEntry -> {
                        val label = when (e.kind) {
                            BrowseKind.ALBUM -> "Album"
                            BrowseKind.ARTIST -> "Artist"
                            else -> ""
                        }
                        title.text = e.title
                        title.setTextColor(white)
                        sub.text = listOf(label, e.subtitle).filter { it.isNotBlank() }.joinToString("  ·  ")
                        sub.visibility = if (sub.text.isEmpty()) View.GONE else View.VISIBLE
                        Images.load(art, e.artworkUrl, dp(52))
                    }
                }
                return row
            }
        }
        lyricAdapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lyricTexts) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getView(position, convertView, parent) as TextView
                val current = position == lyricIndex
                tv.textSize = 20f
                tv.gravity = Gravity.CENTER
                tv.setTextColor(if (current) white else 0xFF6E6E78.toInt())
                tv.setTypeface(null, if (current) Typeface.BOLD else Typeface.NORMAL)
                return tv
            }
        }
        lyricsList.adapter = lyricAdapter

        footer = TextView(this).apply {
            text = "Load more"
            gravity = Gravity.CENTER
            setTextColor(accent)
            textSize = 15f
            setPadding(0, dp(14), 0, dp(14))
            visibility = View.GONE
            setOnClickListener { loadMore() }
        }
        list.addFooterView(footer, null, false)
        list.adapter = adapter
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView, scrollState: Int) {}
            override fun onScroll(view: AbsListView, first: Int, visible: Int, total: Int) {
                if (tab == Tab.RESULTS && total > 0 && first + visible >= total - 2) loadMore()
            }
        })
        list.setOnItemClickListener { _, _, position, _ -> onRowClick(position) }
        list.setOnItemLongClickListener { _, _, position, _ -> onRowLongClick(position); true }
        lyricsList.setOnItemClickListener { _, _, position, _ ->
            lyricLines.getOrNull(position)?.let { service?.seekTo(it.timeMs) }
        }

        findViewById<View>(R.id.search).setOnClickListener { search(query.text.toString()) }
        query.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                search(query.text.toString()); true
            } else false
        }
        for ((k, chip) in kindChips) chip.setOnClickListener { selectKind(k) }
        tabHome.setOnClickListener { showHome() }
        tabLibrary.setOnClickListener { showLibrary() }
        tabQueue.setOnClickListener { tab = Tab.QUEUE; render() }
        backBtn.setOnClickListener { goBack() }
        findViewById<View>(R.id.diag).setOnClickListener { runDiagnostics() }

        // mini player opens the full player; controls
        miniPanel.setOnClickListener { setPlayerOpen(true) }
        miniPlay.setOnClickListener { withService { it.togglePlay() } }
        pPlay.setOnClickListener { withService { it.togglePlay() } }
        findViewById<View>(R.id.prev).setOnClickListener { withService { it.previous() } }
        findViewById<View>(R.id.next).setOnClickListener { withService { it.next() } }
        findViewById<View>(R.id.pClose).setOnClickListener { setPlayerOpen(false) }
        findViewById<View>(R.id.pQueueBtn).setOnClickListener {
            setPlayerOpen(false); tab = Tab.QUEUE; render()
        }
        pLyricsBtn.setOnClickListener { lyricsOn = !lyricsOn; render() }
        pHeart.setOnClickListener {
            val cur = service?.current ?: return@setOnClickListener
            val nowFavorite = Library.toggleFavorite(cur)
            toast(if (nowFavorite) "Added to favorites" else "Removed from favorites")
            libraryChanged()
        }
        pDownload.setOnClickListener {
            val cur = service?.current ?: return@setOnClickListener
            if (Downloads.has(cur)) toast("Already downloaded") else Downloads.start(cur)
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) timeCur.text = fmt(progress.toLong())
            }

            override fun onStartTrackingTouch(bar: SeekBar) { dragging = true }

            override fun onStopTrackingTouch(bar: SeekBar) {
                service?.seekTo(bar.progress.toLong())
                dragging = false
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!goBack()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        showHome()
    }

    override fun onStart() {
        super.onStart()
        bound = bindService(Intent(this, PlaybackService::class.java), connection, Context.BIND_AUTO_CREATE)
        Downloads.listener = { libraryChanged() }
        ui.post(ticker)
    }

    override fun onStop() {
        ui.removeCallbacks(ticker)
        Downloads.listener = null
        service?.onChange = null
        if (bound) { unbindService(connection); bound = false }
        service = null
        super.onStop()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ---- navigation ---------------------------------------------------------------------

    private fun setPlayerOpen(open: Boolean) {
        playerPanel.visibility = if (open) View.VISIBLE else View.GONE
        if (open) tick()
    }

    private fun goBack(): Boolean {
        if (playerPanel.visibility == View.VISIBLE) { setPlayerOpen(false); return true }
        if (tab != Tab.RESULTS) { tab = Tab.RESULTS; render(); return true }
        if (stack.size > 1) { stack.removeAt(stack.lastIndex); render(); return true }
        return false
    }

    private fun showHome() {
        tab = Tab.RESULTS
        openView("Home", replace = true, local = homeEntry, newRoot = Root.HOME) { localSource.open(homeEntry) }
    }

    private fun showLibrary() {
        tab = Tab.RESULTS
        openView("Library", replace = true, local = libraryEntry, newRoot = Root.LIBRARY) { localSource.open(libraryEntry) }
    }

    private fun onRowClick(position: Int) {
        when (tab) {
            Tab.QUEUE -> if (position < shown.size) withService { it.playIndex(position) }
            Tab.RESULTS -> when (val e = shown.getOrNull(position)) {
                is TrackEntry -> {
                    val tracks = shown.filterIsInstance<TrackEntry>().map { it.track }
                    val start = tracks.indexOf(e.track).coerceAtLeast(0)
                    withService { it.playTracks(tracks, start) }
                }
                is BrowseEntry -> openEntry(e)
                else -> {}
            }
        }
    }

    private fun onRowLongClick(position: Int) {
        val e = shown.getOrNull(position) ?: return
        when {
            e is TrackEntry -> showTrackMenu(e.track)
            e is BrowseEntry && e.kind == BrowseKind.LIST && e.ref.startsWith("pl:") -> {
                val name = e.ref.removePrefix("pl:")
                AlertDialog.Builder(this)
                    .setTitle("Delete playlist \"$name\"?")
                    .setPositiveButton("Delete") { _, _ -> Library.deletePlaylist(name); libraryChanged() }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }

    private fun openEntry(e: BrowseEntry) {
        when (e.kind) {
            BrowseKind.PRESET -> {
                kind = SearchKind.SONGS
                query.setText(e.title)
                search(e.ref)
                return
            }
            BrowseKind.LIST -> {
                if (e.ref == "new") {
                    promptNewPlaylist(null)
                } else {
                    openView(e.title, replace = false, local = e) { localSource.open(e) }
                }
                return
            }
            BrowseKind.ARTIST -> {
                // The chips now search for this artist's name (Songs / Albums / Videos).
                lastQuery = e.title
                query.setText(e.title)
                kind = SearchKind.SONGS
            }
            BrowseKind.ALBUM -> {}
        }
        val src = Sources.byId(e.sourceId)
        val label = (if (e.kind == BrowseKind.ALBUM) "Album: " else "Artist: ") + e.title
        openView(label, replace = false) { src.open(e) }
    }

    private fun selectKind(k: SearchKind) {
        kind = k
        val q = lastQuery.ifEmpty { query.text.toString().trim() }
        if (q.isNotEmpty()) search(q) else render()
    }

    private fun search(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        lastQuery = q
        tab = Tab.RESULTS
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(query.windowToken, 0)
        val k = kind
        openView("${k.label}: $q", replace = true, newRoot = Root.SEARCH) { source.search(q, k) }
    }

    /** Loads the first page off the main thread, then shows it as a new screen. */
    private fun openView(
        label: String,
        replace: Boolean,
        local: BrowseEntry? = null,
        newRoot: Root? = null,
        create: () -> ResultPager,
    ) {
        setMessage(if (local == null) "Loading..." else "")
        searchJob?.cancel()
        moreJob?.cancel()
        searchJob = scope.launch {
            try {
                val (pager, first) = withContext(Dispatchers.IO) {
                    val p = create()
                    p to p.next()
                }
                if (replace) {
                    stack.clear()
                    if (newRoot != null) root = newRoot
                }
                stack.add(ViewState(label, pager, ArrayList(first), local))
                tab = Tab.RESULTS
                message = when {
                    local != null -> ""
                    first.isEmpty() -> "Nothing found for this."
                    else -> "Tap a song to play it, long-press for more options."
                }
                render()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                setMessage("Failed:\n" + describe(t))
            }
        }
    }

    private fun loadMore() {
        val v = stack.lastOrNull() ?: return
        if (!v.pager.hasMore || moreJob?.isActive == true || searchJob?.isActive == true) return
        footer.text = "Loading..."
        moreJob = scope.launch {
            try {
                val more = withContext(Dispatchers.IO) { v.pager.next() }
                v.entries.addAll(more)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                message = "Could not load more:\n" + describe(t)
            }
            footer.text = "Load more"
            render()
        }
    }

    /** Rebuilds the on-device list that is on screen (favorites, playlists, ...) after a change. */
    private fun libraryChanged() {
        val v = stack.lastOrNull()
        val ref = v?.local
        if (v != null && ref != null) {
            v.entries.clear()
            v.entries.addAll(localSource.open(ref).next())
        }
        render()
    }

    // ---- menus --------------------------------------------------------------------------

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun showTrackMenu(track: Track) {
        val items = ArrayList<MenuItem>()
        items.add(MenuItem("Add to queue") {
            withService { it.addToQueue(track) }
            toast("Added to queue")
        })
        val fav = Library.isFavorite(track)
        items.add(MenuItem(if (fav) "Remove from favorites" else "Add to favorites") {
            Library.toggleFavorite(track)
            libraryChanged()
        })
        items.add(MenuItem("Add to playlist...") { pickPlaylist(track) })
        val ref = stack.lastOrNull()?.local?.ref
        if (tab == Tab.RESULTS && ref != null && ref.startsWith("pl:")) {
            items.add(MenuItem("Remove from this playlist") {
                Library.removeFromPlaylist(ref.removePrefix("pl:"), track)
                libraryChanged()
            })
        }
        if (Downloads.has(track)) {
            items.add(MenuItem("Delete download") { Downloads.delete(track); libraryChanged() })
        } else {
            items.add(MenuItem("Download") { Downloads.start(track) })
        }
        AlertDialog.Builder(this)
            .setTitle(track.title)
            .setItems(items.map { it.label }.toTypedArray()) { _, which -> items[which].action() }
            .show()
    }

    private fun pickPlaylist(track: Track) {
        val names = Library.playlistNames()
        val labels = (names + "New playlist...").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add to playlist")
            .setItems(labels) { _, which ->
                if (which < names.size) {
                    Library.addToPlaylist(names[which], track)
                    toast("Added to ${names[which]}")
                    libraryChanged()
                } else {
                    promptNewPlaylist(track)
                }
            }
            .show()
    }

    /** Asks for a name and creates the playlist, adding [track] to it when given. */
    private fun promptNewPlaylist(track: Track?) {
        val input = EditText(this).apply {
            hint = "Playlist name"
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("New playlist")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (!Library.createPlaylist(name)) {
                    toast("Pick a name that is not empty or already used")
                } else {
                    if (track != null) Library.addToPlaylist(name, track)
                    toast("Created $name")
                    libraryChanged()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- lyrics -------------------------------------------------------------------------

    private fun loadLyrics(track: Track?) {
        lyricsJob?.cancel()
        lyricLines = emptyList()
        lyricIndex = -1
        if (track == null) {
            lyricsNote = "Nothing playing."
            rebuildLyrics()
            return
        }
        lyricsNote = "Loading lyrics..."
        rebuildLyrics()
        lyricsJob = scope.launch {
            val lines = try {
                LrcLib.lyrics(track.title, track.artist, track.durationSec * 1000L)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                null
            }
            lyricLines = lines.orEmpty().filter { it.text.isNotBlank() }
            lyricsNote = if (lyricLines.isEmpty()) "No synced lyrics found for this song." else ""
            rebuildLyrics()
        }
    }

    private fun rebuildLyrics() {
        lyricTexts.clear()
        if (lyricLines.isEmpty()) lyricTexts.add(lyricsNote) else lyricLines.forEach { lyricTexts.add(it.text) }
        lyricAdapter.notifyDataSetChanged()
    }

    // ---- helpers ------------------------------------------------------------------------

    /** Makes sure the service runs in the foreground (so it survives closing the app), then runs [block]. */
    private fun withService(block: (PlaybackService) -> Unit) {
        val s = service
        if (s == null) {
            setMessage("Player is not ready yet, try again in a second.")
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, PlaybackService::class.java))
        block(s)
    }

    private fun setMessage(text: String) {
        message = text
        render()
    }

    private fun fmt(ms: Long): String =
        String.format(Locale.US, "%d:%02d", ms / 60000, (ms / 1000) % 60)

    private fun render() {
        val s = service
        val cur = s?.current
        val playing = s != null && s.isPlaying

        miniPanel.visibility = if (cur != null) View.VISIBLE else View.GONE
        miniTitle.text = cur?.title ?: ""
        miniArtist.text = cur?.artist ?: ""
        pTitle.text = cur?.title ?: "Nothing playing"
        pArtist.text = cur?.artist ?: ""
        val icon = if (playing) R.drawable.ic_pause else R.drawable.ic_play
        miniPlay.setImageResource(icon)
        pPlay.setImageResource(icon)
        pHeart.setImageResource(if (cur != null && Library.isFavorite(cur)) R.drawable.ic_heart_on else R.drawable.ic_heart)
        pDownload.setColorFilter(if (cur != null && Downloads.has(cur)) accent else white)
        status.text = if (s != null && s.status.isNotEmpty()) s.status else message

        // artwork and lyrics only change when the song does
        val key = cur?.let { "${it.sourceId}:${it.id}" }
        if (key != playingKey) {
            playingKey = key
            Images.load(miniArt, cur?.artworkUrl, dp(44))
            Images.load(pArt, cur?.artworkUrl)
            loadLyrics(cur)
            if (cur != null) Library.addRecent(cur)
        }

        pArt.visibility = if (lyricsOn) View.GONE else View.VISIBLE
        lyricsList.visibility = if (lyricsOn) View.VISIBLE else View.GONE
        pLyricsBtn.setBackgroundResource(if (lyricsOn) R.drawable.chip_on else R.drawable.chip_off)

        refreshList()
        tick()
    }

    private fun styleTab(view: TextView, on: Boolean) {
        view.setTextColor(if (on) white else gray)
        view.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun refreshList() {
        shown.clear()
        val current = stack.lastOrNull()
        when (tab) {
            Tab.RESULTS -> if (current != null) shown.addAll(current.entries)
            Tab.QUEUE -> service?.queue?.forEach { shown.add(TrackEntry(it)) }
        }
        adapter.notifyDataSetChanged()

        footer.visibility =
            if (tab == Tab.RESULTS && current?.pager?.hasMore == true) View.VISIBLE else View.GONE
        backBtn.visibility = if (tab == Tab.RESULTS && stack.size > 1) View.VISIBLE else View.GONE
        viewTitle.text = when (tab) {
            Tab.RESULTS -> current?.label ?: ""
            Tab.QUEUE -> "Queue (${shown.size})"
        }
        styleTab(tabHome, tab == Tab.RESULTS && root == Root.HOME)
        styleTab(tabLibrary, tab == Tab.RESULTS && root == Root.LIBRARY)
        styleTab(tabQueue, tab == Tab.QUEUE)
        for ((k, chip) in kindChips) {
            val on = k == kind
            chip.setBackgroundResource(if (on) R.drawable.chip_on else R.drawable.chip_off)
            chip.setTextColor(if (on) 0xFF000000.toInt() else white)
        }
    }

    private fun tick() {
        val s = service ?: return
        val position = s.positionMs.coerceAtLeast(0)
        val duration = if (s.durationMs > 0) s.durationMs else (s.current?.durationSec ?: 0) * 1000L

        // mini progress bar
        if (duration > 0) {
            miniProgress.max = duration.toInt()
            miniProgress.progress = position.coerceAtMost(duration).toInt()
        } else {
            miniProgress.max = 1; miniProgress.progress = 0
        }

        // current lyric line
        if (lyricLines.isNotEmpty()) {
            val idx = lyricLines.indexOfLast { it.timeMs <= position + 300 }
            if (idx != lyricIndex) {
                lyricIndex = idx
                lyricAdapter.notifyDataSetChanged()
                if (lyricsOn && idx >= 0) lyricsList.setSelectionFromTop(idx, lyricsList.height / 3)
            }
        }

        // full player seek bar
        if (dragging || playerPanel.visibility != View.VISIBLE) return
        if (duration > 0) {
            seek.max = duration.toInt()
            seek.progress = position.coerceAtMost(duration).toInt()
            timeTotal.text = fmt(duration)
        } else {
            seek.max = 1; seek.progress = 0; timeTotal.text = "--:--"
        }
        timeCur.text = fmt(position)
    }

    private fun runDiagnostics() {
        setMessage("Testing...")
        searchJob?.cancel()
        searchJob = scope.launch {
            val report = withContext(Dispatchers.IO) {
                val sb = StringBuilder("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.CPU_ABI}\n")
                sb.append("TLS setup: ${Http.tlsSetupError ?: "ok"}\n")
                for (url in listOf(
                    "https://www.youtube.com/",
                    "https://music.youtube.com/",
                    "https://lrclib.net/api/search?q=test",
                )) {
                    sb.append(url.substringBefore("?")).append(" -> ")
                    try {
                        Http.client.newCall(Request.Builder().url(url).build()).execute().use { sb.append("HTTP ${it.code()}") }
                    } catch (t: Throwable) {
                        sb.append("${t.javaClass.simpleName}: ${t.message}")
                    }
                    sb.append('\n')
                }
                sb.toString()
            }
            setMessage(report)
        }
    }
}
