package com.music.bitchord.lite

import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.music.bitchord.data.Http
import com.music.bitchord.source.AudiusSource
import com.music.bitchord.source.MusicSource
import com.music.bitchord.source.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request

/** Search a song, tap it, hear it. Playback stops when the app is closed (no service yet). */
class MainActivity : AppCompatActivity() {
    private val source: MusicSource = AudiusSource()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var searchJob: Job? = null
    private var playJob: Job? = null

    private lateinit var player: ExoPlayer
    private lateinit var status: TextView
    private lateinit var nowPlaying: TextView
    private lateinit var playPause: Button
    private val results = ArrayList<Track>()
    private lateinit var adapter: ArrayAdapter<Track>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        nowPlaying = findViewById(R.id.nowPlaying)
        playPause = findViewById(R.id.playPause)
        val query = findViewById<EditText>(R.id.query)
        val list = findViewById<ListView>(R.id.results)

        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("BitChordLite/0.1")
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                status.text = when (state) {
                    Player.STATE_BUFFERING -> "Buffering..."
                    Player.STATE_READY -> if (player.isPlaying) "Playing" else "Paused"
                    Player.STATE_ENDED -> "Finished"
                    else -> status.text
                }
                refreshButton()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (player.playbackState == Player.STATE_READY) status.text = if (isPlaying) "Playing" else "Paused"
                refreshButton()
            }

            override fun onPlayerError(error: PlaybackException) {
                status.text = "Playback error: ${error.errorCodeName}\n${describe(error)}"
                refreshButton()
            }
        })

        adapter = object : ArrayAdapter<Track>(this, android.R.layout.simple_list_item_2, android.R.id.text1, results) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = super.getView(position, convertView, parent)
                val t = getItem(position)!!
                row.findViewById<TextView>(android.R.id.text1).text = t.title
                row.findViewById<TextView>(android.R.id.text2).text =
                    "${t.artist}  ·  ${t.durationSec / 60}:${"%02d".format(t.durationSec % 60)}"
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> play(results[position]) }

        findViewById<Button>(R.id.search).setOnClickListener { search(query.text.toString()) }
        query.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                search(query.text.toString()); true
            } else false
        }
        playPause.setOnClickListener {
            if (player.currentMediaItem == null) return@setOnClickListener
            if (player.isPlaying) player.pause() else player.play()
        }
        findViewById<Button>(R.id.diag).setOnClickListener { runDiagnostics() }
        refreshButton()
    }

    private fun search(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        status.text = "Searching..."
        searchJob?.cancel()
        searchJob = scope.launch {
            try {
                val found = withContext(Dispatchers.IO) { source.search(q) }
                results.clear(); results.addAll(found); adapter.notifyDataSetChanged()
                status.text = if (found.isEmpty()) "No results on ${source.name}." else "${found.size} results from ${source.name}. Tap one to play."
            } catch (t: Throwable) {
                status.text = "Search failed: ${t.javaClass.simpleName}: ${t.message}"
            }
        }
    }

    private fun play(track: Track) {
        nowPlaying.text = "${track.title} — ${track.artist}"
        status.text = "Getting stream..."
        playJob?.cancel()
        playJob = scope.launch {
            try {
                val url = withContext(Dispatchers.IO) { source.streamUrl(track) }
                player.setMediaItem(MediaItem.fromUri(url))
                player.prepare()
                player.play()
            } catch (t: Throwable) {
                status.text = "Could not start: ${t.javaClass.simpleName}: ${t.message}"
            }
        }
    }

    private fun refreshButton() {
        playPause.text = if (player.isPlaying) "Pause" else "Play"
    }

    private fun describe(e: Throwable): String {
        val parts = ArrayList<String>()
        var c: Throwable? = e
        while (c != null && parts.size < 3) { parts += "${c.javaClass.simpleName}: ${c.message}"; c = c.cause }
        return parts.joinToString("\n")
    }

    private fun runDiagnostics() {
        status.text = "Testing..."
        searchJob?.cancel()
        searchJob = scope.launch {
            status.text = withContext(Dispatchers.IO) {
                val sb = StringBuilder("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.CPU_ABI}\n")
                sb.append("TLS setup: ${Http.tlsSetupError ?: "ok"}\n")
                for (url in listOf("https://api.audius.co/v1/tracks/trending?app_name=BitChordLite&limit=1")) {
                    sb.append(url.substringBefore("?")).append(" -> ")
                    try {
                        Http.client.newCall(Request.Builder().url(url).build()).execute().use { sb.append("HTTP ${it.code()}") }
                    } catch (t: Throwable) {
                        sb.append("${t.javaClass.simpleName}: ${t.message}")
                    }
                    sb.append('\n')
                }
                sb.toString()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player.pause()
    }

    override fun onDestroy() {
        scope.cancel()
        player.release()
        super.onDestroy()
    }
}
