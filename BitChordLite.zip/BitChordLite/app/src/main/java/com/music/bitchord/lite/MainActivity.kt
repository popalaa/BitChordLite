package com.music.bitchord.lite

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.music.bitchord.data.Http
import com.music.bitchord.source.AudiusSource
import com.music.bitchord.source.MusicSource
import com.music.bitchord.source.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.util.Locale

/** Search, queue and controls. The music itself plays in PlaybackService. */
class MainActivity : AppCompatActivity() {
    private val source: MusicSource = AudiusSource()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var searchJob: Job? = null

    private var service: PlaybackService? = null
    private var bound = false
    private val ui = Handler(Looper.getMainLooper())
    private var dragging = false
    private var showQueue = false
    private var message = "Type a song name and press Search. Long-press a result to add it to the queue."

    private val results = ArrayList<Track>()
    private val shown = ArrayList<Track>()
    private lateinit var adapter: ArrayAdapter<Track>

    private lateinit var status: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var timeCur: TextView
    private lateinit var timeTotal: TextView
    private lateinit var seek: SeekBar
    private lateinit var playPause: Button
    private lateinit var tabResults: Button
    private lateinit var tabQueue: Button

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = (binder as PlaybackService.LocalBinder).service()
            service = s
            s.onChange = { render() }
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) { service = null }
    }

    private val ticker = object : Runnable {
        override fun run() { tick(); ui.postDelayed(this, 500) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        nowTitle = findViewById(R.id.nowTitle)
        nowArtist = findViewById(R.id.nowArtist)
        timeCur = findViewById(R.id.timeCur)
        timeTotal = findViewById(R.id.timeTotal)
        seek = findViewById(R.id.seek)
        playPause = findViewById(R.id.playPause)
        tabResults = findViewById(R.id.tabResults)
        tabQueue = findViewById(R.id.tabQueue)
        val query = findViewById<EditText>(R.id.query)
        val list = findViewById<ListView>(R.id.results)

        adapter = object : ArrayAdapter<Track>(this, R.layout.item_track, R.id.t_title, shown) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = super.getView(position, convertView, parent)
                val t = getItem(position)!!
                val s = service
                val isCurrent = s != null && s.current != null &&
                    (if (showQueue) position == s.index else t.id == s.current?.id)
                val title = row.findViewById<TextView>(R.id.t_title)
                title.text = t.title
                title.setTextColor(if (isCurrent) 0xFF1565C0.toInt() else 0xFF000000.toInt())
                row.findViewById<TextView>(R.id.t_sub).text = "${t.artist}  ·  ${fmt(t.durationSec * 1000L)}"
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ ->
            val track = shown.getOrNull(position) ?: return@setOnItemClickListener
            if (showQueue) withService { it.playIndex(position) }
            else withService { it.playTracks(ArrayList(results), results.indexOf(track).coerceAtLeast(0)) }
        }
        list.setOnItemLongClickListener { _, _, position, _ ->
            if (!showQueue) {
                val track = shown.getOrNull(position) ?: return@setOnItemLongClickListener true
                withService { it.addToQueue(track) }
                Toast.makeText(this, "Added to queue", Toast.LENGTH_SHORT).show()
            }
            true
        }

        findViewById<Button>(R.id.search).setOnClickListener { search(query.text.toString()) }
        query.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                search(query.text.toString()); true
            } else false
        }
        tabResults.setOnClickListener { showQueue = false; refreshList() }
        tabQueue.setOnClickListener { showQueue = true; refreshList() }
        playPause.setOnClickListener { withService { it.togglePlay() } }
        findViewById<Button>(R.id.prev).setOnClickListener { withService { it.previous() } }
        findViewById<Button>(R.id.next).setOnClickListener { withService { it.next() } }
        findViewById<Button>(R.id.diag).setOnClickListener { runDiagnostics() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) timeCur.text = fmt(progress.toLong())
            }

            override fun onStartTrackingTouch(bar: SeekBar) { dragging = true }

            override fun onStopTrackingTouch(bar: SeekBar) {
                service?.seekTo(bar.progress.toLong())
                dragging = false
            }
        })
        refreshList()
    }

    override fun onStart() {
        super.onStart()
        bound = bindService(Intent(this, PlaybackService::class.java), connection, Context.BIND_AUTO_CREATE)
        ui.post(ticker)
    }

    override fun onStop() {
        ui.removeCallbacks(ticker)
        service?.onChange = null
        if (bound) { unbindService(connection); bound = false }
        service = null
        super.onStop()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ---- helpers ------------------------------------------------------------------------

    /** Makes sure the service runs in the foreground (so it survives closing the app), then runs [block]. */
    private fun withService(block: (PlaybackService) -> Unit) {
        val s = service
        if (s == null) {
            setMessage("Player is not ready yet, try again in a second.")
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, PlaybackService::class.java))
        block(s)
    }

    private fun setMessage(text: String) {
        message = text
        render()
    }

    private fun fmt(ms: Long): String =
        String.format(Locale.US, "%d:%02d", ms / 60000, (ms / 1000) % 60)

    private fun render() {
        val s = service
        val cur = s?.current
        nowTitle.text = cur?.title ?: "Nothing playing"
        nowArtist.text = cur?.artist ?: ""
        playPause.text = if (s != null && s.isPlaying) "Pause" else "Play"
        status.text = if (s != null && s.status.isNotEmpty()) s.status else message
        refreshList()
        tick()
    }

    private fun refreshList() {
        shown.clear()
        shown.addAll(if (showQueue) service?.queue.orEmpty() else results)
        adapter.notifyDataSetChanged()
        tabResults.alpha = if (showQueue) 0.5f else 1f
        tabQueue.alpha = if (showQueue) 1f else 0.5f
    }

    private fun tick() {
        val s = service ?: return
        if (dragging) return
        val position = s.positionMs.coerceAtLeast(0)
        val duration = if (s.durationMs > 0) s.durationMs else (s.current?.durationSec ?: 0) * 1000L
        if (duration > 0) {
            seek.max = duration.toInt()
            seek.progress = position.coerceAtMost(duration).toInt()
            timeTotal.text = fmt(duration)
        } else {
            seek.max = 1; seek.progress = 0; timeTotal.text = "--:--"
        }
        timeCur.text = fmt(position)
    }

    private fun search(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        setMessage("Searching...")
        searchJob?.cancel()
        searchJob = scope.launch {
            try {
                val found = withContext(Dispatchers.IO) { source.search(q) }
                results.clear(); results.addAll(found)
                showQueue = false
                message = if (found.isEmpty()) "No results on ${source.name}."
                else "${found.size} results from ${source.name}. Tap to play, long-press to queue."
                render()
            } catch (t: Throwable) {
                setMessage("Search failed: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    private fun runDiagnostics() {
        setMessage("Testing...")
        searchJob?.cancel()
        searchJob = scope.launch {
            val report = withContext(Dispatchers.IO) {
                val sb = StringBuilder("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.CPU_ABI}\n")
                sb.append("TLS setup: ${Http.tlsSetupError ?: "ok"}\n")
                val url = "https://api.audius.co/v1/tracks/trending?app_name=BitChordLite&limit=1"
                sb.append(url.substringBefore("?")).append(" -> ")
                try {
                    Http.client.newCall(Request.Builder().url(url).build()).execute().use { sb.append("HTTP ${it.code()}") }
                } catch (t: Throwable) {
                    sb.append("${t.javaClass.simpleName}: ${t.message}")
                }
                sb.toString()
            }
            setMessage(report)
        }
    }
}
