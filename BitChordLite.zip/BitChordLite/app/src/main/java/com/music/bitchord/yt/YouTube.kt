package com.music.bitchord.yt

import com.music.bitchord.data.Http
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.search.SearchExtractor
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo

/** Pages of raw NewPipe items. Blocking: call from a background thread. */
interface Cursor {
    val hasMore: Boolean
    fun next(): List<InfoItem>
}

/** The only place that talks to NewPipeExtractor, so the source can be swapped later. */
object YouTube {
    @Volatile private var ready = false

    internal fun ensureInit() {
        if (ready) return
        synchronized(this) {
            if (!ready) {
                NewPipe.init(NewPipeDownloader(Http.client))
                ready = true
            }
        }
    }

    /** YouTube Music search filters. */
    val songs: String get() = YoutubeSearchQueryHandlerFactory.MUSIC_SONGS
    val videos: String get() = YoutubeSearchQueryHandlerFactory.MUSIC_VIDEOS
    val albums: String get() = YoutubeSearchQueryHandlerFactory.MUSIC_ALBUMS
    val artists: String get() = YoutubeSearchQueryHandlerFactory.MUSIC_ARTISTS

    fun search(query: String, filter: String): Cursor = SearchCursor(query, filter)

    /** The tracks of an album or playlist. */
    fun playlist(url: String): Cursor = PlaylistCursor(url)

    /**
     * An AAC (m4a) audio URL for the video. AAC because Android 4.4 has no Opus decoder,
     * and a plain progressive URL because that is what ExoPlayer can play directly.
     */
    fun audioUrl(videoUrl: String): String {
        ensureInit()
        val info = StreamInfo.getInfo(ServiceList.YouTube, videoUrl)
        val best = info.audioStreams
            .filter { it.format == MediaFormat.M4A && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .maxByOrNull { it.averageBitrate }
            ?: error("No m4a audio stream (found ${info.audioStreams.size} audio streams)")
        return best.content
    }
}

private class SearchCursor(private val query: String, private val filter: String) : Cursor {
    private var extractor: SearchExtractor? = null
    private var page: ListExtractor.InfoItemsPage<InfoItem>? = null
    override var hasMore = true
        private set

    override fun next(): List<InfoItem> {
        YouTube.ensureInit()
        val ex = extractor
            ?: ServiceList.YouTube.getSearchExtractor(query, listOf(filter), "").also { extractor = it }
        val current = page
        val result = if (current == null) {
            ex.fetchPage()
            ex.initialPage
        } else {
            val np = current.nextPage ?: run { hasMore = false; return emptyList() }
            ex.getPage(np)
        }
        page = result
        hasMore = result.hasNextPage()
        return result.items
    }
}

private class PlaylistCursor(private val url: String) : Cursor {
    private var started = false
    private var nextPage: Page? = null
    override var hasMore = true
        private set

    override fun next(): List<InfoItem> {
        YouTube.ensureInit()
        if (!started) {
            started = true
            val info = PlaylistInfo.getInfo(ServiceList.YouTube, url)
            nextPage = info.nextPage
            hasMore = info.hasNextPage()
            return info.relatedItems
        }
        val np = nextPage ?: run { hasMore = false; return emptyList() }
        val more = PlaylistInfo.getMoreItems(ServiceList.YouTube, url, np)
        nextPage = more.nextPage
        hasMore = more.hasNextPage()
        return more.items
    }
}
