package com.music.bitchord.yt

import com.music.bitchord.data.Http
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class Hit(val title: String, val artist: String, val durationSec: Long, val url: String)

/** The only place that talks to NewPipeExtractor, so the source can be swapped later. */
object YouTube {
    @Volatile private var ready = false

    private fun init() {
        if (ready) return
        synchronized(this) {
            if (!ready) {
                NewPipe.init(NewPipeDownloader(Http.client))
                ready = true
            }
        }
    }

    /**
     * Blocking: call from a background thread.
     * Uses YouTube Music's "songs" filter, so results are the official studio tracks
     * (artist name + song), not covers, lyric videos or live clips.
     */
    fun searchSongs(query: String): List<Hit> {
        init()
        val extractor = ServiceList.YouTube.getSearchExtractor(
            query,
            listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS),
            "",
        )
        extractor.fetchPage()
        return extractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .map { Hit(it.name ?: "?", it.uploaderName ?: "", it.duration, it.url) }
    }

    /**
     * An AAC (m4a) audio URL for the video. AAC because Android 4.4 has no Opus decoder,
     * and a plain progressive URL because that is what ExoPlayer can play directly.
     */
    fun audioUrl(videoUrl: String): String {
        init()
        val info = StreamInfo.getInfo(ServiceList.YouTube, videoUrl)
        val best = info.audioStreams
            .filter { it.format == MediaFormat.M4A && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .maxByOrNull { it.averageBitrate }
            ?: error("No m4a audio stream (found ${info.audioStreams.size} audio streams)")
        return best.content
    }
}
