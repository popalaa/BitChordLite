package com.music.bitchord.yt

import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException

/** Lets NewPipeExtractor make its HTTP calls through our Android 4.4-safe OkHttp client. */
class NewPipeDownloader(private val client: OkHttpClient) : Downloader() {

    override fun execute(request: Request): Response {
        val url = request.url()
        val data = request.dataToSend()
        val body: RequestBody? = if (data != null) RequestBody.create(null as MediaType?, data) else null

        val builder = okhttp3.Request.Builder()
            .method(request.httpMethod(), body)
            .url(url)
            .header("User-Agent", USER_AGENT)
        for ((name, values) in request.headers()) {
            builder.removeHeader(name)
            for (value in values) builder.addHeader(name, value)
        }

        client.newCall(builder.build()).execute().use { response ->
            if (response.code() == 429) throw ReCaptchaException("reCaptcha challenge requested", url)
            return Response(
                response.code(),
                response.message(),
                response.headers().toMultimap(),
                response.body()?.string(),
                response.request().url().toString(),
            )
        }
    }

    companion object {
        const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"
    }
}
