package com.music.bitchord.data

import android.content.Context
import com.music.bitchord.lite.R
import okhttp3.OkHttpClient
import org.conscrypt.Conscrypt
import java.io.ByteArrayInputStream
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * One shared OkHttp 3.12 client (the last line that runs on Android 4.4).
 *
 * Android 4.4 has two problems with today's HTTPS: its own TLS stack is old
 * (fixed by Conscrypt, with TLS 1.2 forced on) and its certificate store
 * predates modern root CAs (fixed by also trusting the bundled Mozilla list).
 */
object Http {
    /** Set once from the Application before the first request. */
    lateinit var appContext: Context

    /** What went wrong while setting up TLS, if anything (shown by the diagnostics). */
    @Volatile var tlsSetupError: String? = null

    val client: OkHttpClient by lazy { build() }

    private fun build(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
        try {
            val trust = trustManager()
            val context = SSLContext.getInstance("TLSv1.2", Conscrypt.newProvider())
            context.init(null, arrayOf(trust), null)
            builder.sslSocketFactory(context.socketFactory, trust)
            // ExoPlayer downloads through HttpURLConnection, which has the same old-TLS
            // problem on Android 4.4, so give it the same socket factory.
            HttpsURLConnection.setDefaultSSLSocketFactory(context.socketFactory)
            // ExoPlayer downloads media through HttpURLConnection, which needs the same fix.
            HttpsURLConnection.setDefaultSSLSocketFactory(context.socketFactory)
        } catch (t: Throwable) {
            tlsSetupError = t.javaClass.simpleName + ": " + t.message
        }
        return builder.build()
    }

    private fun trustManager(): X509TrustManager {
        val store = KeyStore.getInstance(KeyStore.getDefaultType())
        store.load(null, null)

        // 1. Whatever the device already trusts.
        val system = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        system.init(null as KeyStore?)
        system.trustManagers.filterIsInstance<X509TrustManager>().firstOrNull()
            ?.acceptedIssuers?.forEachIndexed { i, cert -> store.setCertificateEntry("sys$i", cert) }

        // 2. The bundled Mozilla roots. Certificates this old device can't parse are skipped.
        val factory = CertificateFactory.getInstance("X.509")
        val pem = appContext.resources.openRawResource(R.raw.cacert).bufferedReader().use { it.readText() }
        Regex("-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\\s]+?-----END CERTIFICATE-----")
            .findAll(pem).forEachIndexed { i, block ->
                runCatching {
                    val cert = factory.generateCertificate(ByteArrayInputStream(block.value.toByteArray()))
                    store.setCertificateEntry("bundled$i", cert)
                }
            }

        val all = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        all.init(store)
        return all.trustManagers.filterIsInstance<X509TrustManager>().first()
    }
}
