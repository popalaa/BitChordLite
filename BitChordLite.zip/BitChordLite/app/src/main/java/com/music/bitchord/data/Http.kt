package com.music.bitchord.data

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** One shared OkHttp 3.12 client (the last line that runs on Android 4.4). */
object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }
}
