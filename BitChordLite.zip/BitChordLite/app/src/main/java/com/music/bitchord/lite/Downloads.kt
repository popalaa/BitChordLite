package com.music.bitchord.lite

import android.content.Context
import android.widget.Toast
import com.music.bitchord.data.Http
import com.music.bitchord.source.Sources
import com.music.bitchord.source.Track
import com.music.bitchord.source.describe
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Saves songs on the device so they play without internet. */
object Downloads {
    private lateinit var dir: File
    private val active = HashSet<String>()

    /** Lives as long as the app process, so a download survives closing the screen. */
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /** Set by the screen while it is visible, to refresh lists when a download ends. */
    var listener: (() -> Unit)? = null

    fun init(context: Context) {
        dir = File(context.getExternalFilesDir(null) ?: context.filesDir, "music").apply { mkdirs() }
    }

    private fun key(t: Track) = "${t.sourceId}:${t.id}"

    private fun file(t: Track): File {
        val hash = MessageDigest.getInstance("MD5").digest(key(t).toByteArray())
            .joinToString("") { "%02x".format(it) }
        return File(dir, "$hash.m4a")
    }

    /** The saved file, or null when the song is not downloaded. */
    fun fileIfExists(t: Track): File? = file(t).takeIf { it.exists() && it.length() > 0 }

    fun has(t: Track) = fileIfExists(t) != null

    fun delete(t: Track) {
        file(t).delete()
        Library.removeDownloaded(t)
        listener?.invoke()
    }

    fun start(t: Track) {
        val ctx = Http.appContext
        if (has(t)) { toast(ctx, "Already downloaded"); return }
        if (!active.add(key(t))) { toast(ctx, "Already downloading"); return }
        toast(ctx, "Downloading: ${t.title}")
        scope.launch {
            val error = try {
                withContext(Dispatchers.IO) { fetch(t) }
                null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                describe(e)
            }
            active.remove(key(t))
            if (error == null) {
                Library.addDownloaded(t)
                toast(ctx, "Downloaded: ${t.title}")
            } else {
                toast(ctx, "Download failed: ${error.take(120)}")
            }
            listener?.invoke()
        }
    }

    /** Blocking. Streams the audio into a temporary file, then renames it. */
    private fun fetch(t: Track) {
        val url = Sources.byId(t.sourceId).streamUrl(t)
        val client = Http.client.newBuilder().readTimeout(30, TimeUnit.SECONDS).build()
        val request = Request.Builder().url(url).header("Range", "bytes=0-").build()
        client.newCall(request).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code()}")
            val body = r.body() ?: throw IOException("Empty response")
            val tmp = File(dir, file(t).name + ".part")
            body.byteStream().use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
            if (!tmp.renameTo(file(t))) throw IOException("Could not save the file")
        }
    }

    private fun toast(ctx: Context, text: String) = Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()
}
