plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.music.bitchord.lite"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.music.bitchord.lite"
        minSdk = 19
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        multiDexEnabled = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.multidex:multidex:2.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    // Last OkHttp line that supports Android 4.4 (the code in BitChord uses OkHttp 5).
    implementation("com.squareup.okhttp3:okhttp:3.12.13")
    // Modern TLS on API 19 (installed in LiteApp).
    implementation("org.conscrypt:conscrypt-android:2.5.2")
    // Last ExoPlayer line that supports Android 4.4 (Media3 needs a newer minSdk).
    implementation("com.google.android.exoplayer:exoplayer-core:2.19.1")
}
