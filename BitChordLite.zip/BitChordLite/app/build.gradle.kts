plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.music.bitchord.lite"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.music.bitchord.lite"
        minSdk = 19
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        multiDexEnabled = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "1.8" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.multidex:multidex:2.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    // Last OkHttp line that supports Android 4.4 (the code in BitChord uses OkHttp 5).
    implementation("com.squareup.okhttp3:okhttp:3.12.13")
    // Modern TLS on API 19 (installed in LiteApp).
    implementation("org.conscrypt:conscrypt-android:2.5.2")
    // Last ExoPlayer line that supports Android 4.4 (Media3 needs a newer minSdk).
    implementation("com.google.android.exoplayer:exoplayer-core:2.19.1")
    // YouTube search + audio extraction. "dev-SNAPSHOT" always resolves; once a build works,
    // replace it with a release tag from github.com/TeamNewPipe/NewPipeExtractor/releases.
    implementation("com.github.TeamNewPipe:NewPipeExtractor:dev-SNAPSHOT")
    // Java 8+ APIs (java.time etc.) that NewPipeExtractor needs below Android 13.
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.0.4")
}
